import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:nti_final_project/screens/product.dart';

class ApiService {
  static const String baseUrl = 'https://accessories-eshop.runasp.net/api';

  static Future<List<Product>> fetchProducts() async {
    await Future.delayed(Duration(milliseconds: 500)); // Simulate network delay
    return [
      Product(
        id: '1',
        name: 'Classic White T-Shirt',
        description: 'Comfortable cotton t-shirt perfect for daily wear',
        imageUrl: 'https://m.media-amazon.com/images/I/A13usaonutL._CLa%7C2140%2C2000%7C91Etm0B3JhL.png%7C0%2C0%2C2140%2C2000%2B0.0%2C0.0%2C2140.0%2C2000.0_AC_UX679_.png',
        price: 19.99,
        category: 'T-shirts',
      ),
      Product(
        id: '2',
        name: 'Blue Denim Jeans',
        description: 'Classic fit denim jeans with modern styling',
        imageUrl: 'https://www.pngall.com/wp-content/uploads/5/Blue-Denim-Jeans-PNG-Image.png',
        price: 49.99,
        category: 'Jeans',
      ),
      Product(
        id: '3',
        name: 'Running Shoes',
        description: 'Lightweight and comfortable running shoes',
        imageUrl: 'https://www.pngall.com/wp-content/uploads/13/Nike-Shoe-PNG-Pic.png',
        price: 79.99,
        category: 'Shoes',
      ),
      Product(
        id: '4',
        name: 'Leather Jacket',
        description: 'Classic leather jacket with modern styling',
        imageUrl: 'https://www.pngall.com/wp-content/uploads/2016/04/Leather-Jacket-PNG-HD.png',
        price: 149.99,
        category: 'Jackets',
      ),
    ];
  }
}

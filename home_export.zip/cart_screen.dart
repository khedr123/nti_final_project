import 'package:flutter/material.dart';
import 'package:nti_final_project/screens/product.dart';
import 'package:nti_final_project/screens/widgets/cart_item_widget.dart';
import 'package:nti_final_project/screens/widgets/constants.dart';
import 'package:nti_final_project/screens/widgets/primary_button.dart';
import 'package:nti_final_project/services/cart_service.dart';

class CartScreen extends StatelessWidget {
  CartScreen({super.key});

  final CartService _cartService = CartService();
  final double shipping = 10.0; // Fixed shipping cost

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'My Cart',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16.0),
            child: Icon(Icons.shopping_cart_outlined, color: Colors.black),
          ),
        ],
      ),
      body: StreamBuilder<List<Product>>(
        stream: _cartService.cartStream,
        initialData: _cartService.cartItems,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(child: Text('Error loading cart items'));
          }

          final cartItems = snapshot.data ?? [];

          if (cartItems.isEmpty) {
            return const Center(
              child: Text(
                'Your cart is empty',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            );
          }

          final subtotal = _cartService.totalPrice;
          final total = subtotal + shipping;

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  itemCount: cartItems.length,
                  itemBuilder: (context, index) {
                    final item = cartItems[index];
                    return CartItemWidget(
                      imageUrl: item.imageUrl ?? '',
                      title: item.name,
                      price: '\$${item.price.toStringAsFixed(2)}',
                      onDelete: () {
                        _cartService.removeFromCart(item);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('${item.name} removed from cart'),
                            duration: const Duration(seconds: 2),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      _buildSummaryRow(
                        'Subtotal',
                        '\$${subtotal.toStringAsFixed(2)}',
                        false,
                      ),
                      _buildSummaryRow(
                        'Shipping',
                        '\$${shipping.toStringAsFixed(2)}',
                        false,
                      ),
                      const Divider(),
                      _buildSummaryRow(
                        'Total',
                        '\$${total.toStringAsFixed(2)}',
                        true,
                      ),
                    ],
                  ),
                ),
              ),
              // زر Checkout
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20.0,
                  vertical: 10.0,
                ),
                child: PrimaryButton(text: 'Checkout', onPressed: () {}),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSummaryRow(String title, String value, bool isTotal) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              color: isTotal ? Colors.black : Colors.black54,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              color: isTotal ? Colors.black : Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}

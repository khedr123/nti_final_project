import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xFF966F33);
const Color kBackgroundColor = Color(0xFFF0F0E0);
const Color kLightInputField = Color(0xFFFAF9F1);
const Color kBottomBarColor = Color(0xFF966F33);

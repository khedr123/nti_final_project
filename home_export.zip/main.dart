import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import 'cubits/login/login_cubit.dart';
import 'features/add_product/presentation/screens/add_service.dart';
import 'features/auth/repository/auth_repository.dart';
import 'features/auth/services/auth_api_service.dart';
import 'screens/cart_screen.dart';
import 'screens/home_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (_) => LoginCubit(AuthRepository(AuthApiService())),
        ),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  static const Color bgColor = Color(0xFFF5F5DE);
  static const Color primaryBrown = Color(0xffA3856E);
  static const Color inputFill = Color(0xFFD9D9D9);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const HomeScreen(),
      title: 'Team Project',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        textTheme: GoogleFonts.poppinsTextTheme(),
        appBarTheme: const AppBarTheme(
          backgroundColor: bgColor,
          elevation: 0,
          centerTitle: true,
        ),
      ),
      routes: {
        '/home': (_) => const HomeScreen(),
        '/addService': (_) => const AddServiceScreen(),
        '/profile': (_) => const ProfileScreen(),
        '/cart': (_) => CartScreen(),
      },
    );
  }
}

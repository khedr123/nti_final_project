import 'package:flutter/material.dart';
import 'package:nti_final_project/screens/product.dart';

class ProductDetailsScreen extends StatelessWidget {
  static const routeName = '/product';
  final Product product;

  const ProductDetailsScreen({required this.product, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F3D9),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF6F3D9),
        elevation: 0,
        leading: const BackButton(color: Colors.black),
        title: Text(product.name, style: const TextStyle(color: Colors.black)),
        actions: const [Icon(Icons.favorite_border, color: Colors.black)],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 250,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: product.imageUrl != null && product.imageUrl!.isNotEmpty
                    ? Image.network(product.imageUrl!)
                    : const Icon(Icons.image, size: 100, color: Colors.grey),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              product.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(
              '\$${product.price}',
              style: const TextStyle(
                fontSize: 20,
                color: Colors.deepOrangeAccent,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              "Description",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            const SizedBox(height: 4),
            Text(product.description ?? 'No description available'),
          ],
        ),
      ),
    );
  }
}

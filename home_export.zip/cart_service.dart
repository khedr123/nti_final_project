import 'dart:async';

import '../screens/product.dart';

class CartService {
  // Singleton pattern
  static final CartService _instance = CartService._internal();
  factory CartService() => _instance;
  CartService._internal();

  final List<Product> _cartItems = [];
  final _cartController = StreamController<List<Product>>.broadcast();

  Stream<List<Product>> get cartStream => _cartController.stream;
  List<Product> get cartItems => List.unmodifiable(_cartItems);
  int get itemCount => _cartItems.length;

  void addToCart(Product product) {
    if (!_cartItems.contains(product)) {
      _cartItems.add(product);
      _cartController.add(_cartItems);
    }
  }

  void removeFromCart(Product product) {
    _cartItems.remove(product);
    _cartController.add(_cartItems);
  }

  void clearCart() {
    _cartItems.clear();
    _cartController.add(_cartItems);
  }

  double get totalPrice =>
      _cartItems.fold(0.0, (sum, product) => sum + product.price);

  void dispose() {
    _cartController.close();
  }
}

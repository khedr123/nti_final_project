class Product {
  final String id;
  final String name;
  final String? description;
  final String? imageUrl;
  final double price;
  final String category;

  Product({
    required this.id,
    required this.name,
    this.description,
    this.imageUrl,
    required this.price,
    required this.category,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id']?.toString() ?? '',
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      imageUrl: json['imageUrl'] ?? '',
      price: (json['price'] ?? 0).toDouble(),
      category: json['category']?.toString() ?? 'All',
    );
  }
}
